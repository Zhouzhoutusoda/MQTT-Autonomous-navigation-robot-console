# 寻迹小车监控系统

这是一个基于Vue3和MQTT的寻迹小车监控系统，用于实时展示小车的各项参数和地图探索状态。

## 功能特点

- 实时3D地图显示小车轨迹和预测路径
- 实时显示小车摄像头图像
- 实时监控霍尔传感器、超声波测距传感器、震动传感器和酒精浓度等传感器数据
- 数据历史趋势图表显示
- 响应式布局设计

## 技术栈

- Vue 3 - 前端框架
- MQTT.js - MQTT客户端库
- Three.js - 3D渲染库
- ECharts - 数据可视化图表库
- Element Plus - UI组件库

## 项目结构

```
src/
├── assets/         # 静态资源
├── components/     # Vue组件
│   ├── MapView.vue     # 3D地图组件
│   ├── CameraView.vue  # 摄像头视图组件
│   └── Dashboard.vue   # 仪表盘组件
├── sensors/        # 传感器数据处理
│   ├── hall.js         # 霍尔传感器数据处理
│   ├── ultrasonic.js   # 超声波测距传感器数据处理
│   ├── vibration.js    # 震动传感器数据处理
│   ├── alcohol.js      # 酒精传感器数据处理
│   └── position.js     # 位置数据处理
├── utils/          # 工具函数
│   └── mqtt.js     # MQTT连接工具
├── views/          # 视图页面
├── App.vue         # 主组件
└── main.js         # 入口文件
```

## 安装与运行

1. 克隆项目

```bash
git clone https://github.com/your-username/car-monitor.git
cd car-monitor
```

2. 安装依赖

```bash
npm install
npm install url stream-browserify buffer util assert webpack process --save-dev
```

3. 运行开发服务器

```bash
npm run serve
```

4. 构建生产版本

```bash
npm run build
```

## 项目配置

项目包含以下配置文件：

- `babel.config.js` - Babel配置
- `.eslintrc.js` - ESLint配置
- `vue.config.js` - Vue CLI和Webpack配置

这些配置文件是必需的，解决了以下问题：

1. Babel配置问题
2. MQTT依赖的Node.js核心模块在浏览器环境中的polyfill问题

## 故障排除

如果遇到以下问题，请尝试对应的解决方案：

1. **Babel配置错误**

错误信息: `No Babel config file detected`

解决方案: 确保项目根目录中存在 `babel.config.js` 文件。

2. **缺少Node.js核心模块**

错误信息: `Module not found: Error: Can't resolve 'url'`

解决方案: 安装所需的polyfill并在vue.config.js中配置webpack。

```bash
npm install url stream-browserify buffer util assert webpack --save-dev
```

3. **ESLint组件命名规则错误**

错误信息: `Component name should always be multi-word`

解决方案: 确保所有Vue组件使用多词命名，例如将 `Dashboard` 改为 `CarDashboard`。

4. **process未定义错误**

错误信息: `Uncaught ReferenceError: process is not defined`

解决方案: 安装process polyfill并在webpack配置中提供process对象：

```bash
npm install process --save-dev
```

然后在`vue.config.js`中添加：

```javascript
module.exports = defineConfig({
  configureWebpack: {
    resolve: {
      fallback: {
        // 其他fallback...
        process: require.resolve('process/browser')
      }
    },
    plugins: [
      new webpack.ProvidePlugin({
        Buffer: ['buffer', 'Buffer'],
        process: 'process/browser'
      })
    ]
  }
})
```

## MQTT主题

系统使用以下MQTT主题接收数据：

- `car/sensor/hall` - 霍尔传感器数据
- `car/sensor/ultrasonic` - 超声波测距传感器数据
- `car/sensor/vibration` - 震动传感器数据
- `car/sensor/alcohol` - 酒精浓度传感器数据
- `car/position` - 位置和方向数据
- `car/camera` - 摄像头图像数据
- `car/map` - 地图数据

## 消息格式

### 霍尔传感器消息

```json
{
  "value": 42.5,
  "unit": "mT",
  "timestamp": 1651234567890
}
```

### 超声波测距消息

```json
{
  "value": 35.8,
  "unit": "cm",
  "timestamp": 1651234567890
}
```

### 震动传感器消息

```json
{
  "value": 12.3,
  "unit": "Hz",
  "timestamp": 1651234567890
}
```

### 酒精浓度消息

```json
{
  "value": 0.05,
  "unit": "mg/L",
  "timestamp": 1651234567890
}
```

### 位置消息

```json
{
  "x": 10.5,
  "y": 20.3,
  "angle": 45.0,
  "timestamp": 1651234567890,
  "prediction": [
    {"x": 12.5, "y": 22.3},
    {"x": 14.5, "y": 24.3}
  ]
}
```

### 相机消息

```json
{
  "imageData": "base64编码的图像数据",
  "timestamp": 1651234567890
}
```

## MQTT服务器配置

系统默认连接到特定的MQTT服务器：

```javascript
const mqttConfig = {
  protocol: 'ws',
  host: '10.42.0.1', // MQTT服务器地址
  port: 8083,
  endpoint: '/mqtt',
  clean: true,
  connectTimeout: 30 * 1000,
  reconnectPeriod: 4000,
  clientId: 'car_monitor_' + Math.random().toString(16).substring(2, 8),
  username: 'wcz',
  password: 'wcz123321.',
}
```

可以在 `src/utils/mqtt.js` 文件中修改这些配置。 