import { ref, computed, watch } from 'vue'
import { receivedMessages } from '../utils/mqtt'
import { topics } from '../utils/mqtt'

// 超声波测距传感器数据
export const distanceValue = ref(0)
export const distanceHistory = ref([])
// 历史记录最大长度
const MAX_HISTORY_LENGTH = 20

// 计算距离状态
export const distanceStatus = computed(() => {
  if (distanceValue.value < 10) return 'close' // 距离过近
  if (distanceValue.value > 200) return 'far'  // 距离过远
  return 'normal'
})

// 监听MQTT消息更新
watch(
  () => receivedMessages.value[topics.ultrasonic],
  (newValue) => {
    // 增加调试日志
    console.log('收到超声波测距数据:', newValue, '类型:', typeof newValue);
    
    if (newValue) {
      // 兼容多种数据格式处理
      // 如果newValue直接是数值，则直接使用
      if (typeof newValue === 'number') {
        distanceValue.value = newValue;
        console.log('处理数值类型:', newValue);
      } 
      // 如果newValue是对象，尝试获取value字段
      else if (typeof newValue === 'object') {
        if (newValue.value !== undefined) {
          distanceValue.value = newValue.value;
          console.log('从对象中提取value字段:', newValue.value);
        } else {
          // 尝试其他可能的字段名
          const possibleFields = ['val', 'data', 'reading', 'distance', 'measurement'];
          for (const field of possibleFields) {
            if (newValue[field] !== undefined && typeof newValue[field] === 'number') {
              distanceValue.value = newValue[field];
              console.log(`从对象中提取${field}字段:`, newValue[field]);
              break;
            }
          }
        }
      }
      // 如果是字符串，尝试转换为数字或JSON
      else if (typeof newValue === 'string') {
        // 尝试直接转为数字
        const numValue = parseFloat(newValue);
        if (!isNaN(numValue)) {
          distanceValue.value = numValue;
          console.log('字符串转换为数值:', numValue);
        } else {
          // 尝试解析字符串为JSON
          try {
            const jsonData = JSON.parse(newValue);
            if (jsonData && typeof jsonData === 'object' && jsonData.value !== undefined) {
              distanceValue.value = jsonData.value;
              console.log('从JSON字符串中提取value:', jsonData.value);
            }
          } catch (e) {
            console.warn('无法解析超声波测距字符串数据:', e);
          }
        }
      }
      
      // 更新历史记录，timestamp字段不是必须的
      const timestamp = (newValue && typeof newValue === 'object' && newValue.timestamp) 
        ? newValue.timestamp 
        : Date.now();
        
      distanceHistory.value.push({
        value: distanceValue.value,
        timestamp: timestamp
      });
      
      // 限制历史记录长度
      if (distanceHistory.value.length > MAX_HISTORY_LENGTH) {
        distanceHistory.value = distanceHistory.value.slice(-MAX_HISTORY_LENGTH);
      }
      
      console.log('距离值已更新为:', distanceValue.value);
    }
  },
  { deep: true, immediate: true }
)

// 获取格式化的距离值
export function getFormattedDistance() {
  return `${distanceValue.value.toFixed(2)} cm`
}

// 获取距离趋势
export function getDistanceTrend() {
  if (distanceHistory.value.length < 2) return 'stable'
  
  const lastIndex = distanceHistory.value.length - 1
  const currentValue = distanceHistory.value[lastIndex].value
  const previousValue = distanceHistory.value[lastIndex - 1].value
  
  if (currentValue > previousValue) return 'rising'
  if (currentValue < previousValue) return 'falling'
  return 'stable'
} 