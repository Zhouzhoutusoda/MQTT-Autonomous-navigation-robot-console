import { ref, watch } from 'vue'
import { receivedMessages } from '../utils/mqtt'
import { topics } from '../utils/mqtt'

// 位置数据
export const position = ref({
  x: 0,
  y: 0,
  angle: 0
})

// 路径历史
export const pathHistory = ref([])
// 最大历史记录点数
const MAX_PATH_POINTS = 100

// 预测路径
export const predictedPath = ref([])

// 监听MQTT消息更新
watch(
  () => receivedMessages.value[topics.position],
  (newValue) => {
    if (newValue) {
      // 更新当前位置
      position.value = {
        x: newValue.x || 0,
        y: newValue.y || 0,
        angle: newValue.angle || 0
      }
      
      // 追加到路径历史
      pathHistory.value.push({
        x: position.value.x,
        y: position.value.y,
        timestamp: newValue.timestamp || Date.now()
      })
      
      // 限制历史路径长度
      if (pathHistory.value.length > MAX_PATH_POINTS) {
        pathHistory.value = pathHistory.value.slice(-MAX_PATH_POINTS)
      }
      
      // 如果有预测数据，更新预测路径
      if (newValue.prediction && Array.isArray(newValue.prediction)) {
        predictedPath.value = newValue.prediction
      }
    }
  },
  { deep: true }
)

// 获取当前位置坐标字符串
export function getPositionString() {
  return `(${position.value.x.toFixed(2)}, ${position.value.y.toFixed(2)})`
}

// 计算行驶距离
export function calculateTravelDistance() {
  if (pathHistory.value.length < 2) return 0
  
  let distance = 0
  for (let i = 1; i < pathHistory.value.length; i++) {
    const prevPoint = pathHistory.value[i - 1]
    const currPoint = pathHistory.value[i]
    
    // 计算两点之间的欧几里得距离
    const dx = currPoint.x - prevPoint.x
    const dy = currPoint.y - prevPoint.y
    distance += Math.sqrt(dx * dx + dy * dy)
  }
  
  return distance.toFixed(2)
}

// 获取转向角度
export function getRotationAngle() {
  return (position.value.angle % 360).toFixed(1)
} 