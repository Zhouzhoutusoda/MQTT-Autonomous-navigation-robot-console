import { ref, computed, watch } from 'vue'
import { receivedMessages } from '../utils/mqtt'
import { topics } from '../utils/mqtt'

// 霍尔传感器数据
export const hallValue = ref(0)
export const hallHistory = ref([])
// 历史记录最大长度
const MAX_HISTORY_LENGTH = 20

// 计算霍尔传感器状态
export const hallStatus = computed(() => {
  if (hallValue.value < 10) return 'low'
  if (hallValue.value > 90) return 'high'
  return 'normal'
})

// 监听MQTT消息更新
watch(
  () => receivedMessages.value[topics.hall],
  (newValue) => {
    // 增加调试日志
    console.log('收到霍尔传感器数据:', newValue, '类型:', typeof newValue);
    
    if (newValue) {
      // 兼容多种数据格式处理
      // 如果newValue直接是数值，则直接使用
      if (typeof newValue === 'number') {
        hallValue.value = newValue;
        console.log('处理数值类型:', newValue);
      } 
      // 如果newValue是对象，尝试获取value字段
      else if (typeof newValue === 'object') {
        if (newValue.value !== undefined) {
          hallValue.value = newValue.value;
          console.log('从对象中提取value字段:', newValue.value);
        } else {
          // 尝试其他可能的字段名
          const possibleFields = ['val', 'data', 'reading', 'measurement'];
          for (const field of possibleFields) {
            if (newValue[field] !== undefined && typeof newValue[field] === 'number') {
              hallValue.value = newValue[field];
              console.log(`从对象中提取${field}字段:`, newValue[field]);
              break;
            }
          }
        }
      }
      // 如果是字符串，尝试转换为数字或JSON
      else if (typeof newValue === 'string') {
        // 尝试直接转为数字
        const numValue = parseFloat(newValue);
        if (!isNaN(numValue)) {
          hallValue.value = numValue;
          console.log('字符串转换为数值:', numValue);
        } else {
          // 尝试解析字符串为JSON
          try {
            const jsonData = JSON.parse(newValue);
            if (jsonData && typeof jsonData === 'object' && jsonData.value !== undefined) {
              hallValue.value = jsonData.value;
              console.log('从JSON字符串中提取value:', jsonData.value);
            }
          } catch (e) {
            console.warn('无法解析霍尔传感器字符串数据:', e);
          }
        }
      }
      
      // 更新历史记录，timestamp字段不是必须的
      const timestamp = (newValue && typeof newValue === 'object' && newValue.timestamp) 
        ? newValue.timestamp 
        : Date.now();
        
      hallHistory.value.push({
        value: hallValue.value,
        timestamp: timestamp
      });
      
      // 限制历史记录长度
      if (hallHistory.value.length > MAX_HISTORY_LENGTH) {
        hallHistory.value = hallHistory.value.slice(-MAX_HISTORY_LENGTH);
      }
      
      console.log('霍尔传感器值已更新为:', hallValue.value);
    }
  },
  { deep: true, immediate: true }
)

// 获取格式化的霍尔传感器值
export function getFormattedHallValue() {
  return `${hallValue.value.toFixed(2)} mT`
}

// 获取霍尔传感器趋势
export function getHallTrend() {
  if (hallHistory.value.length < 2) return 'stable'
  
  const lastIndex = hallHistory.value.length - 1
  const currentValue = hallHistory.value[lastIndex].value
  const previousValue = hallHistory.value[lastIndex - 1].value
  
  if (currentValue > previousValue) return 'rising'
  if (currentValue < previousValue) return 'falling'
  return 'stable'
} 