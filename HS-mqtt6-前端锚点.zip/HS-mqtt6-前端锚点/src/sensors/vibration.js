import { ref, computed, watch } from 'vue'
import { receivedMessages } from '../utils/mqtt'
import { topics } from '../utils/mqtt'

// 震动传感器数据
export const vibrationValue = ref(0)
export const vibrationHistory = ref([])
// 历史记录最大长度
const MAX_HISTORY_LENGTH = 20

// 计算震动状态
export const vibrationStatus = computed(() => {
  if (vibrationValue.value < 10) return 'low'
  if (vibrationValue.value > 80) return 'high'
  return 'normal'
})

// 监听MQTT消息更新
watch(
  () => receivedMessages.value[topics.vibration],
  (newValue) => {
    // 增加调试日志
    console.log('收到震动传感器数据:', newValue, '类型:', typeof newValue);
    
    if (newValue) {
      // 兼容多种数据格式处理
      // 如果newValue直接是数值，则直接使用
      if (typeof newValue === 'number') {
        vibrationValue.value = newValue;
        console.log('处理数值类型:', newValue);
      } 
      // 如果newValue是对象，尝试获取value字段
      else if (typeof newValue === 'object') {
        if (newValue.value !== undefined) {
          vibrationValue.value = newValue.value;
          console.log('从对象中提取value字段:', newValue.value);
        } else {
          // 尝试其他可能的字段名
          const possibleFields = ['val', 'data', 'reading', 'vibration', 'frequency', 'measurement'];
          for (const field of possibleFields) {
            if (newValue[field] !== undefined && typeof newValue[field] === 'number') {
              vibrationValue.value = newValue[field];
              console.log(`从对象中提取${field}字段:`, newValue[field]);
              break;
            }
          }
        }
      }
      // 如果是字符串，尝试转换为数字或JSON
      else if (typeof newValue === 'string') {
        // 尝试直接转为数字
        const numValue = parseFloat(newValue);
        if (!isNaN(numValue)) {
          vibrationValue.value = numValue;
          console.log('字符串转换为数值:', numValue);
        } else {
          // 尝试解析字符串为JSON
          try {
            const jsonData = JSON.parse(newValue);
            if (jsonData && typeof jsonData === 'object' && jsonData.value !== undefined) {
              vibrationValue.value = jsonData.value;
              console.log('从JSON字符串中提取value:', jsonData.value);
            }
          } catch (e) {
            console.warn('无法解析震动传感器字符串数据:', e);
          }
        }
      }
      
      // 更新历史记录，timestamp字段不是必须的
      const timestamp = (newValue && typeof newValue === 'object' && newValue.timestamp) 
        ? newValue.timestamp 
        : Date.now();
        
      vibrationHistory.value.push({
        value: vibrationValue.value,
        timestamp: timestamp
      });
      
      // 限制历史记录长度
      if (vibrationHistory.value.length > MAX_HISTORY_LENGTH) {
        vibrationHistory.value = vibrationHistory.value.slice(-MAX_HISTORY_LENGTH);
      }
      
      console.log('震动值已更新为:', vibrationValue.value);
    }
  },
  { deep: true, immediate: true }
)

// 获取格式化的震动值
export function getFormattedVibration() {
  return `${vibrationValue.value.toFixed(2)} Hz`
}

// 获取震动趋势
export function getVibrationTrend() {
  if (vibrationHistory.value.length < 2) return 'stable'
  
  const lastIndex = vibrationHistory.value.length - 1
  const currentValue = vibrationHistory.value[lastIndex].value
  const previousValue = vibrationHistory.value[lastIndex - 1].value
  
  if (currentValue > previousValue) return 'rising'
  if (currentValue < previousValue) return 'falling'
  return 'stable'
} 