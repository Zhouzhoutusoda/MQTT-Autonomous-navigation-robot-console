<template>
  <div class="container">
    <!-- 正常模式 -->
    <template v-if="!isFullscreen">
      <div class="map-container" @dblclick="toggleFullscreen('map')">
        <MapView />
        <div class="fullscreen-hint">双击全屏</div>
      </div>
      <div class="camera-container" @dblclick="toggleFullscreen('camera')">
        <CameraView />
        <div class="fullscreen-hint">双击全屏</div>
      </div>
      <div class="dashboard-container">
        <CarDashboard />
      </div>
    </template>
    
    <!-- 全屏模式 -->
    <template v-else>
      <div v-if="activeFullscreenComponent === 'map'" class="fullscreen-container" @dblclick="toggleFullscreen('map')">
        <MapView />
        <div class="fullscreen-hint">双击退出全屏</div>
      </div>
      <div v-if="activeFullscreenComponent === 'camera'" class="fullscreen-container" @dblclick="toggleFullscreen('camera')">
        <CameraView />
        <div class="fullscreen-hint">双击退出全屏</div>
      </div>
    </template>
  </div>
</template>

<script>
import MapView from './components/MapView.vue'
import CameraView from './components/CameraView.vue'
import CarDashboard from './components/Dashboard.vue'
import { ref } from 'vue'

export default {
  name: 'App',
  components: {
    MapView,
    CameraView,
    CarDashboard
  },
  setup() {
    const activeFullscreenComponent = ref(null)
    const isFullscreen = ref(false)

    const toggleFullscreen = (componentName) => {
      if (activeFullscreenComponent.value === componentName) {
        // 退出全屏
        activeFullscreenComponent.value = null
        isFullscreen.value = false
      } else {
        // 进入全屏
        activeFullscreenComponent.value = componentName
        isFullscreen.value = true
      }
      
      // 强制重新计算布局
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    }

    return {
      activeFullscreenComponent,
      isFullscreen,
      toggleFullscreen
    }
  }
}
</script>

<style>
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f0f2f5;
}

.container {
  height: 100vh;
  box-sizing: border-box;
}

/* 正常模式样式 */
.container:not(.is-fullscreen) {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
  gap: 20px;
  padding: 20px;
}

.map-container {
  grid-column: 1;
  grid-row: 1;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
}

.camera-container {
  grid-column: 2;
  grid-row: 1 / span 2;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
}

.dashboard-container {
  grid-column: 1;
  grid-row: 2;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
}

/* 全屏模式样式 */
.fullscreen-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: #fff;
  z-index: 1000;
  padding: 0;
  margin: 0;
  overflow: hidden;
}

/* 全屏提示样式 */
.fullscreen-hint {
  position: absolute;
  bottom: 10px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  z-index: 10;
  opacity: 0;
  transition: opacity 0.3s;
}

.map-container:hover .fullscreen-hint,
.camera-container:hover .fullscreen-hint,
.fullscreen-container .fullscreen-hint {
  opacity: 1;
}
</style> 