<template>
  <div class="map-view">
    <div class="title">
      <h3>小车轨迹地图</h3>
      <el-tag v-if="connectionStatus" type="success">已连接</el-tag>
      <el-tag v-else type="danger">未连接</el-tag>
    </div>
    <div ref="mapContainer" class="map-container"></div>
  </div>
</template>

<script>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { createConnection, connectionStatus } from '../utils/mqtt'
import { position, pathHistory, predictedPath } from '../sensors/position'

export default {
  name: 'MapView',
  setup() {
    const mapContainer = ref(null)
    
    // Three.js 对象
    let scene, camera, renderer, controls
    let carMesh, pathLine, predictedPathLine
    
    // 初始化3D场景
    const initThreeJs = () => {
      // 创建场景
      scene = new THREE.Scene()
      scene.background = new THREE.Color(0xf0f0f0)
      
      // 创建相机
      camera = new THREE.PerspectiveCamera(
        75,
        mapContainer.value.clientWidth / mapContainer.value.clientHeight,
        0.1,
        1000
      )
      camera.position.set(0, 30, 30)  // 调整高度和距离
      camera.lookAt(0, 0, 0)
      
      // 创建渲染器
      renderer = new THREE.WebGLRenderer({ antialias: true })
      renderer.setSize(mapContainer.value.clientWidth, mapContainer.value.clientHeight)
      renderer.shadowMap.enabled = true  // 启用阴影
      renderer.shadowMap.type = THREE.PCFSoftShadowMap  // 柔和阴影
      mapContainer.value.appendChild(renderer.domElement)
      
      // 添加轨道控制
      controls = new OrbitControls(camera, renderer.domElement)
      controls.enableDamping = true
      controls.dampingFactor = 0.05  // 增加阻尼效果
      controls.minDistance = 10      // 最小缩放距离
      controls.maxDistance = 100     // 最大缩放距离
      controls.maxPolarAngle = Math.PI / 2.2  // 限制上下旋转角度，防止看到地面下方
      
      // 配置鼠标按键映射，使中键也能用于平移
      controls.mouseButtons = {
        LEFT: THREE.MOUSE.ROTATE,
        MIDDLE: THREE.MOUSE.PAN,
        RIGHT: THREE.MOUSE.PAN
      }
      
      // 创建地面
      const groundSize = 100
      const groundSegments = 20
      
      // 创建地面平面
      const groundGeometry = new THREE.PlaneGeometry(groundSize, groundSize, groundSegments, groundSegments)
      const groundMaterial = new THREE.MeshPhongMaterial({
        color: 0x8B4513,  // 土地颜色
        side: THREE.DoubleSide,
        flatShading: true
      })
      
      const ground = new THREE.Mesh(groundGeometry, groundMaterial)
      ground.rotation.x = Math.PI / 2  // 使平面水平放置
      ground.position.y = -0.1  // 稍微下移，避免与网格线重叠
      ground.receiveShadow = true  // 接收阴影
      scene.add(ground)
      
      // 添加网格地面作为参考线
      const gridHelper = new THREE.GridHelper(100, 20, 0x000000, 0x888888)
      gridHelper.position.y = 0.01  // 稍微上移，避免与地面重叠
      scene.add(gridHelper)
      
      // 添加环境光
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.4)  // 减弱环境光强度
      scene.add(ambientLight)
      
      // 添加定向光（模拟太阳光）
      const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
      directionalLight.position.set(50, 100, 50)
      directionalLight.castShadow = true  // 启用阴影投射
      
      // 设置阴影参数
      directionalLight.shadow.mapSize.width = 1024
      directionalLight.shadow.mapSize.height = 1024
      directionalLight.shadow.camera.near = 10
      directionalLight.shadow.camera.far = 200
      directionalLight.shadow.camera.left = -50
      directionalLight.shadow.camera.right = 50
      directionalLight.shadow.camera.top = 50
      directionalLight.shadow.camera.bottom = -50
      
      scene.add(directionalLight)
      
      // 创建小车模型
      createCarModel()
      
      // 创建路径线
      createPathLine()
      
      // 开始动画循环
      animate()
      
      // 监听窗口大小变化
      window.addEventListener('resize', onWindowResize)
    }
    
    // 创建小车模型
    const createCarModel = () => {
      // 创建车身组
      carMesh = new THREE.Group()
      
      // 主车身 - 底盘
      const bodyGeometry = new THREE.BoxGeometry(3.5, 0.5, 6)
      const bodyMaterial = new THREE.MeshPhongMaterial({ color: 0x3399ff })
      const bodyMesh = new THREE.Mesh(bodyGeometry, bodyMaterial)
      bodyMesh.position.set(0, 0.5, 0)
      bodyMesh.castShadow = true  // 投射阴影
      carMesh.add(bodyMesh)
      
      // 车厢
      const cabinGeometry = new THREE.BoxGeometry(3, 1.2, 3.5)
      const cabinMaterial = new THREE.MeshPhongMaterial({ color: 0x2277dd })
      const cabinMesh = new THREE.Mesh(cabinGeometry, cabinMaterial)
      cabinMesh.position.set(0, 1.6, -0.5)
      cabinMesh.castShadow = true  // 投射阴影
      carMesh.add(cabinMesh)
      
      // 添加车轮
      const wheelRadius = 0.8
      const wheelThickness = 0.5
      const wheelGeometry = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelThickness, 16)
      const wheelMaterial = new THREE.MeshPhongMaterial({ color: 0x222222 })
      
      // 车轮位置
      const wheelPositions = [
        [-1.8, wheelRadius, -2],  // 左前
        [1.8, wheelRadius, -2],   // 右前
        [-1.8, wheelRadius, 2],   // 左后
        [1.8, wheelRadius, 2]     // 右后
      ]
      
      // 创建并添加车轮
      wheelPositions.forEach(position => {
        const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial)
        wheel.position.set(...position)
        wheel.rotation.z = Math.PI / 2  // 旋转车轮使其正确朝向
        wheel.castShadow = true  // 投射阴影
        carMesh.add(wheel)
      })
      
      // 添加前灯
      const headlightGeometry = new THREE.BoxGeometry(0.5, 0.3, 0.1)
      const headlightMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xffffcc, 
        emissive: 0xffffcc,
        emissiveIntensity: 0.5
      })
      
      // 前灯位置
      const headlightPositions = [
        [-1.2, 0.8, -3],  // 左前灯
        [1.2, 0.8, -3]    // 右前灯
      ]
      
      // 创建并添加前灯
      headlightPositions.forEach(position => {
        const headlight = new THREE.Mesh(headlightGeometry, headlightMaterial)
        headlight.position.set(...position)
        headlight.castShadow = true  // 投射阴影
        carMesh.add(headlight)
      })
      
      // 添加防滚架
      const rollBarGeometry = new THREE.CylinderGeometry(0.1, 0.1, 3.5, 8)
      const rollBarMaterial = new THREE.MeshPhongMaterial({ color: 0xdddddd })
      const rollBar = new THREE.Mesh(rollBarGeometry, rollBarMaterial)
      rollBar.position.set(0, 2.3, 0)
      rollBar.rotation.x = Math.PI / 2
      rollBar.castShadow = true  // 投射阴影
      carMesh.add(rollBar)
      
      // 添加方向指示器（箭头）
      const arrowGeometry = new THREE.ConeGeometry(0.5, 1, 8)
      const arrowMaterial = new THREE.MeshPhongMaterial({ color: 0xff3333 })
      const arrowMesh = new THREE.Mesh(arrowGeometry, arrowMaterial)
      arrowMesh.position.set(0, 1, -3.5)  // 放在车头前方
      arrowMesh.rotation.x = Math.PI / 2
      arrowMesh.castShadow = true  // 投射阴影
      
      carMesh.add(arrowMesh)
      scene.add(carMesh)
      
      // 初始位置
      updateCarPosition()
    }
    
    // 创建路径线
    const createPathLine = () => {
      // 历史路径
      const pathMaterial = new THREE.LineBasicMaterial({ color: 0x00ff00, linewidth: 2 })
      const pathGeometry = new THREE.BufferGeometry()
      pathLine = new THREE.Line(pathGeometry, pathMaterial)
      scene.add(pathLine)
      
      // 预测路径
      const predictedPathMaterial = new THREE.LineBasicMaterial({ color: 0xff6600, linewidth: 2, dashSize: 1, gapSize: 1 })
      const predictedPathGeometry = new THREE.BufferGeometry()
      predictedPathLine = new THREE.Line(predictedPathGeometry, predictedPathMaterial)
      scene.add(predictedPathLine)
    }
    
    // 更新小车位置
    const updateCarPosition = () => {
      if (carMesh) {
        // 设置位置
        carMesh.position.set(position.value.x, 1, position.value.y)
        
        // 设置旋转角度
        carMesh.rotation.y = -position.value.angle * Math.PI / 180
      }
      
      // 更新历史路径线
      if (pathLine && pathHistory.value.length > 0) {
        const points = pathHistory.value.map(point => new THREE.Vector3(point.x, 1, point.y))
        pathLine.geometry.setFromPoints(points)
        pathLine.geometry.attributes.position.needsUpdate = true
      }
      
      // 更新预测路径线
      if (predictedPathLine && predictedPath.value.length > 0) {
        const points = predictedPath.value.map(point => new THREE.Vector3(point.x, 1, point.y))
        predictedPathLine.geometry.setFromPoints(points)
        predictedPathLine.geometry.attributes.position.needsUpdate = true
      }
    }
    
    // 窗口大小调整
    const onWindowResize = () => {
      if (!mapContainer.value) return; // 确保容器存在
      
      camera.aspect = mapContainer.value.clientWidth / mapContainer.value.clientHeight
      camera.updateProjectionMatrix()
      renderer.setSize(mapContainer.value.clientWidth, mapContainer.value.clientHeight)
    }
    
    // 添加ResizeObserver以处理容器大小变化
    const setupResizeObserver = () => {
      const resizeObserver = new ResizeObserver(() => {
        onWindowResize();
      });
      
      // 观察容器元素大小变化
      if (mapContainer.value) {
        resizeObserver.observe(mapContainer.value);
      }
      
      return resizeObserver;
    }
    
    // 动画循环
    const animate = () => {
      requestAnimationFrame(animate)
      
      // 更新控制
      controls.update()
      
      // 更新小车位置
      updateCarPosition()
      
      // 渲染场景
      renderer.render(scene, camera)
    }
    
    // 组件挂载后初始化
    onMounted(() => {
      // 创建MQTT连接
      createConnection()
      
      // 初始化3D场景
      if (mapContainer.value) {
        initThreeJs()
        
        // 设置ResizeObserver
        const resizeObserver = setupResizeObserver();
        
        // 组件卸载前清理ResizeObserver
        onBeforeUnmount(() => {
          if (resizeObserver && mapContainer.value) {
            resizeObserver.unobserve(mapContainer.value);
            resizeObserver.disconnect();
          }
        });
      }
    })
    
    // 组件卸载前清理
    onBeforeUnmount(() => {
      window.removeEventListener('resize', onWindowResize)
      
      // 释放THREE.js资源
      if (renderer) {
        renderer.dispose()
        if (mapContainer.value) {
          mapContainer.value.removeChild(renderer.domElement)
        }
      }
    })
    
    return {
      mapContainer,
      connectionStatus
    }
  }
}
</script>

<style scoped>
.map-view {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  background-color: #fff;
}

.title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 16px;
  height: 50px;
  z-index: 10;
}

.map-container {
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* 确保canvas元素填充容器 */
.map-container canvas {
  width: 100% !important;
  height: 100% !important;
  display: block;
}

/* 处理全屏模式 */
:deep(.fullscreen) .map-view {
  height: 100vh;
  width: 100vw;
}
</style> 