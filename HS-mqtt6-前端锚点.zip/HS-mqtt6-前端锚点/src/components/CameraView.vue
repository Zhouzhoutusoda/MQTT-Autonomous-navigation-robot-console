<template>
  <div class="camera-view">
    <div class="title">
      <h3>实时监控画面</h3>
      <div class="status">
        <el-tag v-if="streamActive" type="success">正在接收视频流</el-tag>
        <el-tag v-else type="warning">等待视频流...</el-tag>
      </div>
    </div>
    <div class="camera-container">
      <div v-if="imageUrl" class="camera-feed">
        <img :src="imageUrl" :alt="'小车摄像头 ' + lastUpdateTime" @load="handleImageLoad" />
        <div class="stream-info">
          <span class="fps">{{ frameRate.toFixed(1) }} FPS</span>
          <span class="timestamp">更新时间: {{ lastUpdateTime }}</span>
        </div>
      </div>
      <div v-else class="no-signal">
        <el-icon :size="48"><VideoCamera /></el-icon>
        <p>等待视频信号...</p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed, watch, onBeforeUnmount, nextTick } from 'vue'
import { VideoCamera } from '@element-plus/icons-vue'
import { receivedMessages, topics, subscribeToTopic } from '../utils/mqtt'

// 添加ResizeObserver错误处理
const handleResizeObserverError = () => {
  window.addEventListener('error', (event) => {
    if (event.message && event.message.includes('ResizeObserver')) {
      event.stopImmediatePropagation();
    }
  });
};

export default {
  name: 'CameraView',
  components: {
    VideoCamera
  },
  setup() {
    // 图像URL (base64格式)
    const imageUrl = ref('')
    // 上次更新时间
    const lastUpdateTime = ref('')
    // 帧率计算
    const frameCount = ref(0)
    const frameRate = ref(0)
    const lastFrameTime = ref(Date.now())
    // 图像加载状态
    const imageLoading = ref(false)
    
    // 计算视频流是否激活
    const streamActive = computed(() => !!imageUrl.value)
    
    // 格式化时间
    const formatTime = (timestamp) => {
      const date = new Date(timestamp)
      return date.toLocaleTimeString()
    }
    
    // 处理图像加载完成事件
    const handleImageLoad = () => {
      imageLoading.value = false;
      // 使用nextTick延迟大小计算，避免重复触发ResizeObserver
      nextTick(() => {
        // 图像加载完成
      });
    }
    
    // 更新图像数据
    const updateImage = (imageData) => {
      // 防止频繁更新引起的ResizeObserver问题
      if (imageLoading.value) return;
      
      imageLoading.value = true;
      
      // 尝试不同的图像格式
      if (imageData.startsWith('data:image')) {
        // 已经是完整的data URL
        imageUrl.value = imageData
      } else if (imageData.startsWith('/9j/') || imageData.startsWith('iVBOR')) {
        // 看起来是base64数据，但缺少前缀
        const format = imageData.startsWith('/9j/') ? 'jpeg' : 'png'
        imageUrl.value = `data:image/${format};base64,${imageData}`
      } else {
        // 假设是base64编码的JPEG
        imageUrl.value = `data:image/jpeg;base64,${imageData}`
      }
      
      // 更新时间戳
      lastUpdateTime.value = formatTime(Date.now())
      
      // 更新帧率计算
      frameCount.value++
      const now = Date.now()
      const elapsed = now - lastFrameTime.value
      
      if (elapsed >= 1000) { // 每秒更新一次帧率
        frameRate.value = (frameCount.value / elapsed) * 1000
        frameCount.value = 0
        lastFrameTime.value = now
      }
    }
    
    // 监听相机消息
    const watchCameraFeed = () => {
      // 添加对receivedMessages的监听
      const unwatch = watch(
        () => receivedMessages.value[topics.camera],
        (newValue) => {
          if (!newValue) return
          
          console.log('收到相机数据:', typeof newValue, newValue && typeof newValue === 'object' ? Object.keys(newValue) : '不是对象')
          
          try {
            // 处理不同的数据格式
            if (typeof newValue === 'string') {
              // 直接是base64字符串
              updateImage(newValue)
            } else if (typeof newValue === 'object') {
              // 如果是对象格式，尝试读取imageData属性
              if (newValue.imageData) {
                updateImage(newValue.imageData)
              } else if (newValue.image) {
                updateImage(newValue.image)
              } else if (newValue.data) {
                updateImage(newValue.data)
              } else if (newValue.base64) {
                updateImage(newValue.base64)
              } else {
                // 如果没有已知的属性，尝试找到任何看起来像base64的字段
                const possibleImageField = Object.entries(newValue).find(([, value]) => 
                  typeof value === 'string' && value.length > 100
                )
                
                if (possibleImageField) {
                  updateImage(possibleImageField[1])
                } else {
                  console.warn('无法解析相机数据:', newValue)
                }
              }
            } else {
              console.warn('不支持的相机数据类型:', typeof newValue)
            }
          } catch (error) {
            console.error('处理相机数据出错:', error)
          }
        },
        { immediate: true, deep: true }
      )
      
      return unwatch
    }
    
    // 确保额外订阅所有可能的相机主题
    const subscribeToExtraTopics = () => {
      // 订阅一些额外的可能相关的主题
      const extraTopics = [
        'camera/#',
        'video/#',
        'image/#',
        'stream/#'
      ]
      
      extraTopics.forEach(topic => {
        subscribeToTopic(topic)
      })
    }
    
    // 定时清理过时的图像和重置帧率（避免长时间无数据时仍显示旧图像）
    let cleanupInterval = null
    
    onMounted(() => {
      // 处理ResizeObserver错误
      handleResizeObserverError();
      
      // 开始监听相机消息
      watchCameraFeed()
      
      // 订阅额外的主题
      subscribeToExtraTopics()
      
      // 设置清理定时器
      cleanupInterval = setInterval(() => {
        const now = Date.now()
        // 如果10秒内没有新帧，则认为流已停止
        if (now - lastFrameTime.value > 10000 && imageUrl.value) {
          frameRate.value = 0
          console.log('相机流超时，未收到新帧')
          
          // 防止ResizeObserver问题，可以考虑在长时间无数据时移除图像
          if (now - lastFrameTime.value > 30000) {
            imageUrl.value = '';
          }
        }
      }, 5000)
    })
    
    onBeforeUnmount(() => {
      if (cleanupInterval) {
        clearInterval(cleanupInterval)
      }
    })
    
    return {
      imageUrl,
      lastUpdateTime,
      streamActive,
      frameRate,
      handleImageLoad
    }
  }
}
</script>

<style scoped>
.camera-view {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  background-color: #fff;
}

.title {
  padding: 10px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #eee;
  z-index: 10;
}

.camera-container {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  background-color: #000;
  position: relative;
}

.camera-feed {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.camera-feed img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

/* 全屏模式时的调整 */
:deep(.fullscreen) .camera-view {
  height: 100vh;
  width: 100vw;
}

:deep(.fullscreen) .camera-feed img {
  max-height: 90vh;
}

.stream-info {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background-color: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  display: flex;
  gap: 15px;
  z-index: 10;
}

.fps {
  background-color: rgba(0, 0, 0, 0.5);
  color: #00ff00;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-family: monospace;
}

.timestamp {
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
}

.no-signal {
  color: #999;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px;
}

.no-signal p {
  margin-top: 10px;
}
</style> 