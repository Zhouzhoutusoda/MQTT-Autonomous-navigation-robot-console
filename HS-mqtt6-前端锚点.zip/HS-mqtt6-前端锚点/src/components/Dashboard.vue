<template>
  <div class="dashboard">
    <div class="title">
      <h3>小车状态仪表盘</h3>
      <div class="header-controls">
        <div v-if="activeView !== 'grid'" class="back-button">
          <el-button type="primary" size="small" @click="backToGrid">
            <el-icon><Back /></el-icon> 返回传感器总览
          </el-button>
        </div>
        <div class="mqtt-status">
          <el-tag v-if="connectionStatus" type="success">MQTT已连接</el-tag>
          <el-tag v-else type="danger">MQTT未连接</el-tag>
        </div>
      </div>
    </div>
    
    <!-- 传感器网格视图 -->
    <div v-if="activeView === 'grid'" class="sensors-grid">
      <!-- 霍尔传感器 -->
      <div class="sensor-card" 
           :class="{ 'alert': hallStatus !== 'normal' }"
           @click="showSensorChart('hall')">
        <div class="sensor-icon">
          <el-icon><Sunny /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">霍尔传感器</div>
          <div class="sensor-value">{{ getFormattedHallValue() }}</div>
          <div class="sensor-trend">
            <el-icon v-if="getHallTrend() === 'rising'"><ArrowUp /></el-icon>
            <el-icon v-else-if="getHallTrend() === 'falling'"><ArrowDown /></el-icon>
            <el-icon v-else><Minus /></el-icon>
          </div>
        </div>
        <div class="view-details">
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>
      
      <!-- 超声波测距传感器 -->
      <div class="sensor-card" 
           :class="{ 'alert': distanceStatus !== 'normal' }"
           @click="showSensorChart('ultrasonic')">
        <div class="sensor-icon">
          <el-icon><Odometer /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">超声波测距</div>
          <div class="sensor-value">{{ getFormattedDistance() }}</div>
          <div class="sensor-trend">
            <el-icon v-if="getDistanceTrend() === 'rising'"><ArrowUp /></el-icon>
            <el-icon v-else-if="getDistanceTrend() === 'falling'"><ArrowDown /></el-icon>
            <el-icon v-else><Minus /></el-icon>
          </div>
        </div>
        <div class="view-details">
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>
      
      <!-- 震动传感器 -->
      <div class="sensor-card" 
           :class="{ 'alert': vibrationStatus !== 'normal' }"
           @click="showSensorChart('vibration')">
        <div class="sensor-icon">
          <el-icon><Dish /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">震动传感器</div>
          <div class="sensor-value">{{ getFormattedVibration() }}</div>
          <div class="sensor-trend">
            <el-icon v-if="getVibrationTrend() === 'rising'"><ArrowUp /></el-icon>
            <el-icon v-else-if="getVibrationTrend() === 'falling'"><ArrowDown /></el-icon>
            <el-icon v-else><Minus /></el-icon>
          </div>
        </div>
        <div class="view-details">
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>
      
      <!-- 酒精传感器 -->
      <div class="sensor-card" 
           :class="{ 'alert': alcoholStatus !== 'normal' }"
           @click="showSensorChart('alcohol')">
        <div class="sensor-icon">
          <el-icon><Dessert /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">酒精传感器</div>
          <div class="sensor-value">{{ getFormattedAlcoholLevel() }}</div>
          <div class="sensor-trend">
            <el-icon v-if="getAlcoholTrend() === 'rising'"><ArrowUp /></el-icon>
            <el-icon v-else-if="getAlcoholTrend() === 'falling'"><ArrowDown /></el-icon>
            <el-icon v-else><Minus /></el-icon>
          </div>
        </div>
        <div class="view-details">
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>
      
      <!-- 位置信息 -->
      <div class="sensor-card" @click="showSensorChart('position')">
        <div class="sensor-icon">
          <el-icon><Location /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">当前位置</div>
          <div class="sensor-value">{{ getPositionString() }}</div>
          <div class="sensor-label">旋转角度: {{ getRotationAngle() }}°</div>
        </div>
        <div class="view-details">
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>
      
      <!-- 行驶距离 -->
      <div class="sensor-card">
        <div class="sensor-icon">
          <el-icon><Position /></el-icon>
        </div>
        <div class="sensor-data">
          <div class="sensor-title">行驶距离</div>
          <div class="sensor-value">{{ calculateTravelDistance() }} 米</div>
        </div>
      </div>
    </div>
    
    <!-- 单个传感器数据图表视图 -->
    <div v-else class="single-chart-container">
      <div ref="singleChartContainer" class="chart"></div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { ArrowUp, ArrowDown, Minus, Sunny, Odometer, Dish, Location, Position, ArrowRight, Back, Dessert } from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import { connectionStatus } from '../utils/mqtt'

// 导入传感器数据
import { 
  position, calculateTravelDistance, 
  getPositionString, getRotationAngle, pathHistory
} from '../sensors/position'

import { 
  hallValue, hallStatus, hallHistory,
  getFormattedHallValue, getHallTrend 
} from '../sensors/hall'

import { 
  distanceValue, distanceStatus, distanceHistory, 
  getFormattedDistance, getDistanceTrend 
} from '../sensors/ultrasonic'

import { 
  vibrationValue, vibrationStatus, vibrationHistory, 
  getFormattedVibration, getVibrationTrend 
} from '../sensors/vibration'

import { 
  alcoholLevel, alcoholStatus, alcoholHistory, 
  getFormattedAlcoholLevel, getAlcoholTrend 
} from '../sensors/alcohol'

export default {
  name: 'CarDashboard',
  components: {
    ArrowUp, ArrowDown, Minus, Sunny, Odometer, Dish, Location, Position, ArrowRight, Back, Dessert
  },
  setup() {
    const singleChartContainer = ref(null)
    let chart = null
    
    // 当前视图：grid(网格) 或 特定传感器ID
    const activeView = ref('grid')
    
    // 添加ResizeObserver以处理容器大小变化
    let resizeObserver = null
    
    // 监听容器大小变化并调整图表大小
    const setupResizeObserver = () => {
      // 如果已经存在，先清除旧的observer
      if (resizeObserver) {
        resizeObserver.disconnect();
      }
      
      resizeObserver = new ResizeObserver(() => {
        if (chart && singleChartContainer.value) {
          chart.resize();
        }
      });
      
      // 观察图表容器大小变化
      if (singleChartContainer.value) {
        resizeObserver.observe(singleChartContainer.value);
      }
    }
    
    // 返回网格视图
    const backToGrid = () => {
      activeView.value = 'grid'
      // 销毁当前图表实例
      if (chart) {
        chart.dispose()
        chart = null
      }
    }
    
    // 显示特定传感器的图表
    const showSensorChart = (sensorId) => {
      activeView.value = sensorId
      
      nextTick(() => {
        // 图表可能需要先销毁再重新创建
        if (chart) {
          chart.dispose()
          chart = null
        }
        
        if (!singleChartContainer.value) return
        
        chart = echarts.init(singleChartContainer.value)
        
        // 根据传感器类型创建不同的图表
        initSensorChart(sensorId)
        
        // 设置ResizeObserver
        setupResizeObserver();
      })
    }
    
    // 为特定传感器初始化图表
    const initSensorChart = (sensorId) => {
      if (!singleChartContainer.value) return
      
      chart = echarts.init(singleChartContainer.value)
      
      let option = {
        title: {
          text: getSensorTitle(sensorId),
          left: 'center'
        },
        tooltip: {
          trigger: 'axis'
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '12%',
          top: '15%',
          containLabel: true
        },
        xAxis: {
          type: 'time',
          boundaryGap: false
        },
        yAxis: {
          type: 'value',
          name: getSensorUnit(sensorId)
        },
        series: [
          {
            name: getSensorTitle(sensorId),
            type: 'line',
            data: getSensorData(sensorId),
            smooth: true,
            lineStyle: {
              width: 2
            },
            areaStyle: {}
          }
        ]
      }
      
      // 位置数据特殊处理
      if (sensorId === 'position') {
        option = getPositionChartOption()
      }
      
      chart.setOption(option)
      
      // 设置窗口大小变化时调整图表
      window.addEventListener('resize', handleResize)
    }
    
    // 获取传感器标题
    const getSensorTitle = (sensorId) => {
      const titles = {
        'hall': '霍尔传感器数据趋势',
        'ultrasonic': '超声波测距数据趋势',
        'vibration': '震动传感器数据趋势',
        'alcohol': '酒精浓度数据趋势',
        'position': '位置轨迹'
      }
      return titles[sensorId] || '数据趋势'
    }
    
    // 获取传感器单位
    const getSensorUnit = (sensorId) => {
      const units = {
        'hall': '磁场强度 (mT)',
        'ultrasonic': '距离 (cm)',
        'vibration': '震动频率 (Hz)',
        'alcohol': '浓度 (mg/L)',
        'position': '坐标'
      }
      return units[sensorId] || ''
    }
    
    // 获取传感器数据
    const getSensorData = (sensorId) => {
      let data = []
      
      if (sensorId === 'hall') {
        data = hallHistory.value.map(item => [
          new Date(item.timestamp),
          item.value
        ])
      } else if (sensorId === 'ultrasonic') {
        data = distanceHistory.value.map(item => [
          new Date(item.timestamp),
          item.value
        ])
      } else if (sensorId === 'vibration') {
        data = vibrationHistory.value.map(item => [
          new Date(item.timestamp),
          item.value
        ])
      } else if (sensorId === 'alcohol') {
        data = alcoholHistory.value.map(item => [
          new Date(item.timestamp),
          item.value
        ])
      }
      
      return data
    }
    
    // 位置图表特殊处理
    const getPositionChartOption = () => {
      // 转换位置历史为轨迹点
      const positionPoints = pathHistory.value.map(p => [p.x, p.y])
      
      return {
        title: {
          text: '位置轨迹',
          left: 'center'
        },
        tooltip: {
          trigger: 'item',
          formatter: function(params) {
            return `坐标: (${params.value[0].toFixed(2)}, ${params.value[1].toFixed(2)})`
          }
        },
        xAxis: {
          type: 'value',
          name: 'X轴',
          scale: true
        },
        yAxis: {
          type: 'value',
          name: 'Y轴',
          scale: true
        },
        series: [
          {
            name: '位置轨迹',
            type: 'line',
            data: positionPoints,
            smooth: true,
            symbol: 'circle',
            symbolSize: 8,
            itemStyle: {
              color: '#409EFF'
            },
            lineStyle: {
              width: 2,
              color: '#409EFF'
            }
          }
        ]
      }
    }
    
    // 更新当前激活的图表
    const updateSensorChart = () => {
      if (!chart || activeView.value === 'grid') return
      
      try {
        // 更新特定传感器的图表
        if (activeView.value === 'hall' || 
            activeView.value === 'ultrasonic' || 
            activeView.value === 'vibration' ||
            activeView.value === 'alcohol') {
              
          chart.setOption({
            series: [
              { data: getSensorData(activeView.value) }
            ]
          })
        }
        // 位置图表特殊处理
        else if (activeView.value === 'position') {
          const positionPoints = pathHistory.value.map(p => [p.x, p.y])
          chart.setOption({
            series: [
              { data: positionPoints }
            ]
          })
        }
      } catch (error) {
        console.error('更新图表数据错误:', error);
      }
    }
    
    // 添加防抖函数来处理resize事件
    const debounce = (fn, delay) => {
      let timer = null;
      return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timer);
        timer = setTimeout(() => {
          fn.apply(context, args);
        }, delay);
      };
    };
    
    // 处理窗口大小变化
    const handleResize = debounce(() => {
      if (chart) {
        chart.resize();
      }
    }, 100);
    
    // 定期更新图表
    let chartUpdateInterval = null
    
    onMounted(() => {
      // 处理ResizeObserver错误
      window.addEventListener('error', (event) => {
        if (event.message && event.message.includes('ResizeObserver')) {
          event.stopImmediatePropagation();
        }
      });
      
      // 设置定时更新
      chartUpdateInterval = setInterval(() => {
        updateSensorChart();
      }, 2000);
      
      // 使用防抖的resize处理器
      window.addEventListener('resize', handleResize);
    })
    
    onBeforeUnmount(() => {
      // 清除定时器
      if (chartUpdateInterval) {
        clearInterval(chartUpdateInterval);
      }
      
      // 移除事件监听器
      window.removeEventListener('resize', handleResize);
      
      // 销毁图表实例
      if (chart) {
        chart.dispose();
        chart = null;
      }
      
      // 清理ResizeObserver
      if (resizeObserver) {
        resizeObserver.disconnect();
        resizeObserver = null;
      }
    })
    
    return {
      singleChartContainer,
      connectionStatus,
      activeView,
      showSensorChart,
      backToGrid,
      // 位置相关
      position,
      getPositionString, getRotationAngle, calculateTravelDistance,
      // 霍尔传感器相关
      hallValue, hallStatus,
      getFormattedHallValue, getHallTrend,
      // 超声波测距相关
      distanceValue, distanceStatus,
      getFormattedDistance, getDistanceTrend,
      // 震动传感器相关
      vibrationValue, vibrationStatus,
      getFormattedVibration, getVibrationTrend,
      // 酒精传感器相关
      alcoholLevel, alcoholStatus,
      getFormattedAlcoholLevel, getAlcoholTrend
    }
  }
}
</script>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
}

.title {
  padding: 0 16px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-controls {
  display: flex;
  align-items: center;
  gap: 12px;
}

.back-button {
  margin-right: 8px;
}

.mqtt-status {
  display: flex;
  align-items: center;
}

.sensors-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  padding: 0 16px 16px;
  flex: 1;
  overflow-y: auto;
}

.sensor-card {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 16px;
  display: flex;
  align-items: center;
  transition: all 0.3s;
  cursor: pointer;
  position: relative;
}

.sensor-card:hover {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  transform: translateY(-2px);
}

.sensor-card.alert {
  background-color: #fef0f0;
}

.sensor-icon {
  font-size: 24px;
  margin-right: 16px;
  color: #409eff;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  background-color: rgba(64, 158, 255, 0.1);
  border-radius: 50%;
}

.sensor-data {
  flex: 1;
}

.sensor-title {
  font-size: 14px;
  color: #909399;
  margin-bottom: 4px;
}

.sensor-value {
  font-size: 24px;
  font-weight: bold;
  display: flex;
  align-items: center;
}

.sensor-trend {
  display: inline-flex;
  align-items: center;
  margin-left: 8px;
}

.sensor-trend .el-icon {
  font-size: 16px;
}

.sensor-label {
  font-size: 14px;
  color: #606266;
  margin-top: 4px;
}

.view-details {
  color: #409eff;
  opacity: 0.6;
  transition: all 0.3s;
}

.sensor-card:hover .view-details {
  opacity: 1;
}

.single-chart-container {
  flex: 1;
  margin: 0 16px 16px;
  background-color: #fff;
  border-radius: 8px;
  overflow: hidden;
  display: flex;
}

.chart {
  width: 100%;
  height: 100%;
}
</style> 